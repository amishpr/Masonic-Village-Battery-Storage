# FanController
Arduino library to control 3 and 4 pins fans

At this moment it supports up to 6 fans, depending on board ([https://www.arduino.cc/en/Reference/AttachInterrupt](https://www.arduino.cc/en/Reference/AttachInterrupt))
